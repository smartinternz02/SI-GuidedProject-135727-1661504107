function resultLoadFunction(){
    var text = window.location.hash.substring(1);
    alert('in the new page');
    alert(text);
}